import pickle

with open("trainer/labels.pickle", "rb") as f:
    labels = pickle.load(f)
    print("Isi label:", labels)
