import os
import cv2
import numpy as np
from keras_facenet import FaceNet

# Inisialisasi model
embedder = FaceNet()

# Path gambar Virgilia
img_path = 'dataset/virgilia/virgilia.jpg'
img = cv2.imread(img_path)

if img is None:
    print("❌ Gambar tidak ditemukan:", img_path)
    exit()

# Deteksi dan ekstrak wajah
faces = embedder.extract(img, threshold=0.95)

if len(faces) == 0:
    print("😢 Tidak ada wajah terdeteksi!")
    exit()

embedding = faces[0]['embedding']

# Simpan hasil embedding
os.makedirs("data", exist_ok=True)
np.save("data/virgilia_embeddings.npy", embedding)

print("✅ Embedding Virgilia berhasil disimpan!")
