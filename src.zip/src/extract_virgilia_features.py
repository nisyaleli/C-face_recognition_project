import cv2
import numpy as np
from keras_facenet import FaceNet
import os

# Inisialisasi model FaceNet
embedder = FaceNet()

# Path ke gambar Virgilia
image_path = "dataset/virgilia/virgilia.jpg"
img = cv2.imread(image_path)

# Cek apakah gambar berhasil dibaca
if img is None:
    raise FileNotFoundError(f"Gambar tidak ditemukan di path: {image_path}")

# Convert BGR ke RGB
rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

# Deteksi wajah dan ekstrak embedding
embeddings = embedder.embeddings([rgb_img])
embedding = embeddings[0]

# Buat folder output kalau belum ada
os.makedirs("embeddings", exist_ok=True)

# Simpan embedding ke file .npy
output_path = "embeddings/virgilia_embeddings.npy"
np.save(output_path, embedding)

print(f"[INFO] Embedding wajah Virgilia disimpan di: {output_path}")
