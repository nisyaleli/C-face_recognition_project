import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__)))

from utils import load_face, get_embedding
from keras.models import load_model
import numpy as np
from glob import glob

# Load model
model = load_model("facenet_keras.h5")

# Ambil semua path gambar dari folder waifu
image_paths = glob("dataset/waifu/*.jpg")  # atau *.png tergantung dataset

embeddings = []

for img_path in image_paths:
    face = load_face(img_path)
    if face is not None:
        embedding = get_embedding(model, face)
        embeddings.append(embedding)

embeddings = np.asarray(embeddings)

# Simpan hasil embedding
np.save("dataset/waifu_embeddings.npy", embeddings)
np.save("dataset/filenames_waifu.npy", image_paths)

