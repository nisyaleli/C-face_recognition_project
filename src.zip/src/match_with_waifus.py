import numpy as np
import face_recognition

# Load embeddings
virgilia_embedding = np.load("embeddings/virgilia_embeddings.npy")
waifu_embeddings = np.load("embeddings/waifu_embeddings.npy", allow_pickle=True).item()

# Hitung jarak
def cosine_distance(a, b):
    return 1 - np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

distances = {
    name: cosine_distance(embedding, virgilia_embedding)
    for name, embedding in waifu_embeddings.items()
}

# Ambil waifu terbaik
best_match = min(distances, key=distances.get)
print(f"💘 Waifu terbaik untuk kamu: {best_match}")
print(f"📊 Nilai cosine distance: {distances[best_match]:.4f}")
