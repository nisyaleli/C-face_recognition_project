import os
import cv2
import numpy as np
import pickle

# Setup direktori dasar
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
image_dir = os.path.join(BASE_DIR, "dataset")
cascade_path = os.path.join(BASE_DIR, "haarcascade", "haarcascade_frontalface_default.xml")
trainer_dir = os.path.join(BASE_DIR, "trainer")

# Auto buat folder trainer kalau belum ada
if not os.path.exists(trainer_dir):
    os.makedirs(trainer_dir)

# Load classifier wajah
face_cascade = cv2.CascadeClassifier(cascade_path)
recognizer = cv2.face.LBPHFaceRecognizer_create()

# Persiapan data
current_id = 0
label_ids = {}
x_train = []
y_labels = []

# Loop semua folder dan file di dataset
for root, dirs, files in os.walk(image_dir):
    for file in files:
        if file.lower().endswith(("png", "jpg", "jpeg")):
            path = os.path.join(root, file)
            label = os.path.basename(root).replace(" ", "_").lower()

            if label not in label_ids:
                label_ids[label] = current_id
                current_id += 1

            id_ = label_ids[label]
            # Baca gambar dan convert ke grayscale
            image = cv2.imread(path)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # Deteksi wajah
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
            for (x, y, w, h) in faces:
                roi = gray[y:y + h, x:x + w]
                x_train.append(roi)
                y_labels.append(id_)

# Simpan label ke file pickle
with open(os.path.join(trainer_dir, "labels.pickle"), 'wb') as f:
    pickle.dump(label_ids, f)

# Latih model
recognizer.train(x_train, np.array(y_labels))
recognizer.save(os.path.join(trainer_dir, "trainer.yml"))

print("[INFO] Training selesai. Model disimpan di folder trainer/")
