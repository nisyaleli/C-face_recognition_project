# src/utils.py

import numpy as np
import cv2
from keras.models import load_model

def load_face(image_path, required_size=(160, 160)):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Gagal load gambar: {image_path}")
    img = cv2.resize(img, required_size)
    img = img.astype('float32') / 255.0
    img = np.expand_dims(img, axis=0)
    return img

def get_embedding(model, face_pixels):
    return model.predict(face_pixels)[0]
